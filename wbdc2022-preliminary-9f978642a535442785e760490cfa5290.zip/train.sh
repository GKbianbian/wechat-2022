cd src/ 

python down_load.py

python main.py
