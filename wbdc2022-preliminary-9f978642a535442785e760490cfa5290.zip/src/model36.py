import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertModel,RobertaModel

import math
from category_id_map import CATEGORY_ID_LIST
from transformers.models.bert.modeling_bert import BertConfig, BertOnlyMLMHead
from transformers.models.bert.modeling_bert import BertPreTrainedModel, BertEmbeddings, BertEncoder
from typing import Any, Callable, Dict, List, NewType, Optional, Tuple, Union
from transformers import AutoTokenizer

class MultiModal(nn.Module):
    def __init__(self, args):
        super().__init__()
        # 这里是导入bert模型
        bertconfig = BertConfig.from_pretrained('input/pretrain-model/roberta-wwm/config.json')
        self.bert = BertModel.from_pretrained('input/pretrain-model/roberta-wwm')
        # self.bert = BertModel.from_pretrained(args.bert_dir, cache_dir=args.bert_cache)

        # self.video_bert = BertModel.from_pretrained(args.bert_dir, cache_dir=args.bert_cache)
        # self.nextvlad = NeXtVLAD(args.frame_embedding_size, args.vlad_cluster_size,
        #                          output_size=args.vlad_hidden_size, dropout=args.dropout)
        self.enhance = SENet(channels=args.vlad_hidden_size, ratio=args.se_ratio)
        bert_output_size = 768
        self.args = args
        # self.fusion = ConcatDenseSE(args.vlad_hidden_size + bert_output_size, args.fc_size, args.se_ratio, args.dropout)
        self.v_layer = nn.Linear(768, 768)
        self.classifier = nn.Linear(768, len(CATEGORY_ID_LIST))
        self.drop = nn.Dropout(p=0.3)
        self.pooler = MeanPooling()

        # pretrain
        if self.args.do_pretrain:
            self.sample_task = ['mlm','mfm']
            self.lm = MaskLM(tokenizer_path='input/pretrain-model/roberta-wwm')
            self.vm = MaskVideo()
            self.roberta_mvm_lm_header = VisualOnlyMLMHead(bertconfig)
            self.cls = BertOnlyMLMHead(bertconfig)
            self.vocab_size = bertconfig.vocab_size


    def forward(self, inputs, inference=False):


#         bert_embedding = self.bert(inputs['title_input'], inputs['title_mask'])['pooler_output']

#         vision_embedding = self.nextvlad(inputs['frame_input'], inputs['frame_mask'])
#         vision_embedding = self.enhance(vision_embedding)

#         final_embedding = self.fusion([vision_embedding, bert_embedding])

        v_embed = self.v_layer(inputs['frame_input'])
        v_embed = self.bert.embeddings(inputs_embeds=v_embed)
        text_emb = self.bert.embeddings(input_ids=inputs['title_input'])
    
        cls_emb = text_emb[:, 0:1, :]
        text_emb = text_emb[:, 1:, :]
        cls_mask = inputs['title_mask'][:, 0:1]
        text_mask = inputs['title_mask'][:, 1:]

        embedding_output = torch.cat([cls_emb, v_embed, text_emb], 1)
        mask = torch.cat([cls_mask, inputs['frame_mask'], text_mask], 1)
        fusion_mask = mask[:, None, None, :]
        fusion_mask = (1.0 - fusion_mask) * -10000.0
        encoder_outputs = self.bert.encoder(embedding_output, attention_mask=fusion_mask)['last_hidden_state']

        if self.args.do_pretrain:
            loss = 0.
            if 'mlm' in self.sample_task:
                input_ids, lm_label = self.lm.torch_mask_tokens(inputs['title_input'].cpu(),)
                text_input_ids = input_ids.to(inputs['title_input'].device)
                lm_label = lm_label[:, 1:].to(inputs['title_input'].device)  # [SEP] 卡 MASK 大师 [SEP]

            if 'mfm' in self.sample_task:
                vm_input = inputs['frame_input']
                input_feature, video_label = self.vm.torch_mask_frames(inputs['frame_input'].cpu(),inputs['frame_mask'].cpu())
                video_feature = input_feature.to(inputs['frame_mask'].device)
                video_label = video_label.to(inputs['frame_mask'].device)

            lm_prediction_scores = self.cls(encoder_outputs)[:, 1 + video_feature.size()[1]: , :]
            if 'mlm' in self.sample_task:
                pred = lm_prediction_scores.contiguous().view(-1, self.vocab_size)
                masked_lm_loss = nn.CrossEntropyLoss()(pred, lm_label.contiguous().view(-1))
                loss += masked_lm_loss / 1.25 / len(self.sample_task)

            if 'mfm' in self.sample_task:
                vm_output = self.roberta_mvm_lm_header(encoder_outputs[:, 1:video_feature.size()[1] + 1, :])
                masked_vm_loss = self.calculate_mfm_loss(vm_output, vm_input,
                                                         inputs['frame_mask'], video_label, normalize=False)
                loss += masked_vm_loss / 3 / len(self.sample_task)
            return loss,masked_lm_loss,masked_vm_loss

        else:
            pooling_output = self.drop(encoder_outputs)
            pooling_output = self.pooler(pooling_output, mask)
        # embed_max=encoder_outputs+(1-mask).unsqueeze(-1)*(-1e10)
        # embed_max=embed_max.max(1)[0].float()

        # final_hidden_state = torch.cat([embed_max,pooling_output],-1)
        # final_hidden_state = self.enhance(final_hidden_state)
        # print(final_hidden_state.shape)
            prediction = self.classifier(pooling_output)
            if inference:
                # return torch.argmax(prediction, dim=1)
                return prediction
            else:
                return self.cal_loss(prediction, inputs['label'])

    @staticmethod
    def cal_loss(prediction, label):
        label = label.squeeze(dim=1)
        loss = F.cross_entropy(prediction, label)
        with torch.no_grad():
            pred_label_id = torch.argmax(prediction, dim=1)
            accuracy = (label == pred_label_id).float().sum() / label.shape[0]
        return loss, accuracy, pred_label_id, label

    def calculate_mfm_loss(self, video_feature_output, video_feature_input,
                           video_mask, video_labels_index, normalize=False, temp=0.1):
        if normalize:
            video_feature_output = torch.nn.functional.normalize(video_feature_output, p=2, dim=2)
            video_feature_input = torch.nn.functional.normalize(video_feature_input, p=2, dim=2)

        afm_scores_tr = video_feature_output.view(-1, video_feature_output.shape[-1])

        video_tr = video_feature_input.permute(2, 0, 1)
        video_tr = video_tr.view(video_tr.shape[0], -1)

        logits_matrix = torch.mm(afm_scores_tr, video_tr)
        if normalize:
            logits_matrix = logits_matrix / temp

        video_mask_float = video_mask.to(dtype=torch.float)
        mask_matrix = torch.mm(video_mask_float.view(-1, 1), video_mask_float.view(1, -1))
        masked_logits = logits_matrix + (1. - mask_matrix) * -1e8

        logpt = F.log_softmax(masked_logits, dim=-1)
        logpt = torch.diag(logpt)
        nce_loss = -logpt

        video_labels_index_mask = (video_labels_index != -100)
        nce_loss = nce_loss.masked_select(video_labels_index_mask.view(-1))
        nce_loss = nce_loss.mean()
        return nce_loss

class MeanPooling(nn.Module):
    def __init__(self):
        super(MeanPooling, self).__init__()

    def forward(self, last_hidden_state, attention_mask):
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(last_hidden_state.size()).float()
        sum_embeddings = torch.sum(last_hidden_state * input_mask_expanded, 1)
        sum_mask = input_mask_expanded.sum(1)
        sum_mask = torch.clamp(sum_mask, min=1e-9)
        mean_embeddings = sum_embeddings / sum_mask
        return mean_embeddings    
    

class NeXtVLAD(nn.Module):
    def __init__(self, feature_size, cluster_size, output_size=1024, expansion=2, groups=8, dropout=0.2):
        super().__init__()
        self.feature_size = feature_size
        self.output_size = output_size
        self.expansion_size = expansion
        self.cluster_size = cluster_size
        self.groups = groups
        self.drop_rate = dropout

        self.new_feature_size = self.expansion_size * self.feature_size // self.groups

        self.dropout = torch.nn.Dropout(self.drop_rate)
        self.expansion_linear = torch.nn.Linear(self.feature_size, self.expansion_size * self.feature_size)
        self.group_attention = torch.nn.Linear(self.expansion_size * self.feature_size, self.groups)
        self.cluster_linear = torch.nn.Linear(self.expansion_size * self.feature_size, self.groups * self.cluster_size,
                                              bias=False)
        self.cluster_weight = torch.nn.Parameter(
            torch.nn.init.normal_(torch.rand(1, self.new_feature_size, self.cluster_size), std=0.01))
        self.fc = torch.nn.Linear(self.new_feature_size * self.cluster_size, self.output_size)

    def forward(self, inputs, mask):
        # todo mask
        inputs = self.expansion_linear(inputs)
        attention = self.group_attention(inputs)
        attention = torch.sigmoid(attention)
        attention = attention.reshape([-1, inputs.size(1) * self.groups, 1])
        reshaped_input = inputs.reshape([-1, self.expansion_size * self.feature_size])
        activation = self.cluster_linear(reshaped_input)
        activation = activation.reshape([-1, inputs.size(1) * self.groups, self.cluster_size])
        activation = torch.softmax(activation, dim=-1)
        activation = activation * attention
        a_sum = activation.sum(-2, keepdim=True)
        a = a_sum * self.cluster_weight
        activation = activation.permute(0, 2, 1).contiguous()
        reshaped_input = inputs.reshape([-1, inputs.shape[1] * self.groups, self.new_feature_size])
        vlad = torch.matmul(activation, reshaped_input)
        vlad = vlad.permute(0, 2, 1).contiguous()
        vlad = F.normalize(vlad - a, p=2, dim=1)
        vlad = vlad.reshape([-1, self.cluster_size * self.new_feature_size])
        vlad = self.dropout(vlad)
        vlad = self.fc(vlad)
        return vlad


class SENet(nn.Module):
    def __init__(self, channels, ratio=8):
        super().__init__()
        self.sequeeze = nn.Linear(in_features=channels, out_features=channels // ratio, bias=False)
        self.relu = nn.ReLU()
        self.excitation = nn.Linear(in_features=channels // ratio, out_features=channels, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        gates = self.sequeeze(x)
        gates = self.relu(gates)
        gates = self.excitation(gates)
        gates = self.sigmoid(gates)
        x = torch.mul(x, gates)

        return x


class ConcatDenseSE(nn.Module):
    def __init__(self, multimodal_hidden_size, hidden_size, se_ratio, dropout):
        super().__init__()
        self.fusion = nn.Linear(multimodal_hidden_size, hidden_size)
        self.fusion_dropout = nn.Dropout(dropout)
        self.enhance = SENet(channels=hidden_size, ratio=se_ratio)

    def forward(self, inputs):
        embeddings = torch.cat(inputs, dim=1)
        embeddings = self.fusion_dropout(embeddings)
        embedding = self.fusion(embeddings)
        embedding = self.enhance(embedding)

        return embedding


class MaskLM(object):
    def __init__(self, tokenizer_path='hfl/chinese-roberta-wwm-ext', mlm_probability=0.15):
        self.mlm_probability = 0.15
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_path)

    def torch_mask_tokens(self, inputs, special_tokens_mask=None):
        """
        Prepare masked tokens inputs/labels for masked language modeling: 80% MASK, 10% random, 10% original.
        """
        labels = inputs.clone()
        # We sample a few tokens in each sequence for MLM training (with probability `self.mlm_probability`)
        probability_matrix = torch.full(labels.shape, self.mlm_probability)
        if special_tokens_mask is None:
            special_tokens_mask = [
                self.tokenizer.get_special_tokens_mask(val, already_has_special_tokens=True) for val in labels.tolist()
            ]
            special_tokens_mask = torch.tensor(special_tokens_mask, dtype=torch.bool)
        else:
            special_tokens_mask = special_tokens_mask.bool()

        probability_matrix.masked_fill_(special_tokens_mask, value=0.0)
        masked_indices = torch.bernoulli(probability_matrix).bool()
        labels[~masked_indices] = -100  # We only compute loss on masked tokens

        # 80% of the time, we replace masked input tokens with tokenizer.mask_token ([MASK])
        indices_replaced = torch.bernoulli(torch.full(labels.shape, 0.8)).bool() & masked_indices
        inputs[indices_replaced] = self.tokenizer.convert_tokens_to_ids(self.tokenizer.mask_token)

        # 10% of the time, we replace masked input tokens with random word
        indices_random = torch.bernoulli(torch.full(labels.shape, 0.5)).bool() & masked_indices & ~indices_replaced
        random_words = torch.randint(len(self.tokenizer), labels.shape, dtype=torch.long)
        inputs[indices_random] = random_words[indices_random]

        # The rest of the time (10% of the time) we keep the masked input tokens unchanged
        return inputs, labels


class MaskVideo(object):
    def __init__(self, mlm_probability=0.15):
        self.mlm_probability = 0.15

    def torch_mask_frames(self, video_feature, video_mask):
        probability_matrix = torch.full(video_mask.shape, 0.9 * self.mlm_probability)
        probability_matrix = probability_matrix * video_mask

        masked_indices = torch.bernoulli(probability_matrix).bool()

        video_labels_index = torch.arange(video_feature.size(0) * video_feature.size(1)).view(-1, video_feature.size(1))
        video_labels_index = -100 * ~masked_indices + video_labels_index * masked_indices

        # 90% mask video fill all 0.0
        masked_indices_unsqueeze = masked_indices.unsqueeze(-1).expand_as(video_feature)
        inputs = video_feature.data.masked_fill(masked_indices_unsqueeze, 0.0)
        labels = video_feature[masked_indices_unsqueeze].contiguous().view(-1, video_feature.size(2))

        return inputs, video_labels_index
# class ClassificationHead(nn.Module):
#     """Head for sentence-level classification tasks."""
#     def __init__(self):
#         super().__init__()
#         self.dense = nn.Linear(768, 1536)
#         self.dropout = nn.Dropout(0.3)
#         self.dense_1 = nn.Linear(1536, 512)  
#         self.out_proj = nn.Linear(512, 200)

#     def forward(self, features, **kwargs):

#         x = self.dense(features)
#         x = torch.relu(x)
#         x = self.dropout(x)
#         x = self.dense_1(x)
#         x = torch.relu(x)
# #         x = self.dropout(x)        
# #         x = self.out_proj(x)
#         return x
class VisualLMPredictionHead(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.transform = VisualPredictionHeadTransform(config)

        # The output weights are the same as the input embeddings, but there is
        # an output-only bias for each token.
        self.decoder = nn.Linear(config.hidden_size, 768, bias=False)
        self.bias = nn.Parameter(torch.zeros(768))

        # Need a link between the two variables so that the bias is correctly resized with `resize_token_embeddings`
        self.decoder.bias = self.bias

    def forward(self, hidden_states):
        hidden_states = self.transform(hidden_states)
        hidden_states = self.decoder(hidden_states)
        return hidden_states

class VisualOnlyMLMHead(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.predictions = VisualLMPredictionHead(config)

    def forward(self, sequence_output):
        prediction_scores = self.predictions(sequence_output)
        return prediction_scores


def gelu(x):
    """Implementation of the gelu activation function.
    For information: OpenAI GPT's gelu is slightly different (and gives slightly different results):
    0.5 * x * (1 + torch.tanh(math.sqrt(2 / math.pi) * (x + 0.044715 * torch.pow(x, 3))))
    """
    return x * 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))

def swish(x):
    return x * torch.sigmoid(x)

ACT2FN = {"gelu": gelu, "relu": torch.nn.functional.relu, "swish": swish}


class VisualPredictionHeadTransform(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        if isinstance(config.hidden_act, str):
            self.transform_act_fn = ACT2FN[config.hidden_act]
        else:
            self.transform_act_fn = config.hidden_act
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)

    def forward(self, hidden_states):
        hidden_states = self.dense(hidden_states)
        hidden_states = self.transform_act_fn(hidden_states)
        hidden_states = self.LayerNorm(hidden_states)
        return hidden_states