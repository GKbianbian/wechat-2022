import torch
from torch.utils.data import SequentialSampler, DataLoader
import numpy as np  
from config36 import parse_args
from data_helper36 import MultiModalDataset
from category_id_map import lv2id_to_category_id
from model36 import MultiModal
from collections import Counter    
def inference():
    args = parse_args()
    # 1. load data
    dataset = MultiModalDataset(args, args.test_annotation, args.test_zip_feats, test_mode=True)
    sampler = SequentialSampler(dataset)
    dataloader = DataLoader(dataset,
                            batch_size=args.test_batch_size,
                            sampler=sampler,
                            drop_last=False,
                            pin_memory=True,
                            num_workers=args.num_workers,
                            prefetch_factor=args.prefetch)

    all_path = ['save/v1/model_epoch_2_1027.bin',
                'save/v1/model_epoch_2_1995.bin',
                'save/v1/model_epoch_2_200.bin',
                'save/v1/model_epoch_2_2000.bin',
                'save/v1/model_epoch_2_2004.bin',
               'save/v1/model_epoch_2_2005.bin',
                'save/v1/model_epoch_2_2008.bin',
                'save/v1/model_epoch_2_2016.bin',
                'save/v1/model_epoch_2_2021.bin',
                'save/v1/model_epoch_2_2022.bin',
                'save/v1/model_epoch_2_42.bin']

    pre = []
    for path in all_path:
        # checkpoint = torch.load(args.ckpt_file, map_location='cpu')
        # 2. load model
        model = MultiModal(args)
        checkpoint = torch.load(path, map_location='cpu')
        model.load_state_dict(checkpoint['model_state_dict'])
        if torch.cuda.is_available():
            model = torch.nn.parallel.DataParallel(model.cuda())
        model.eval()
        # 3. inference
        predictions = []
        with torch.no_grad():
            for batch in dataloader:
                pred_label_id = model(batch, inference=True)
                predictions.extend(pred_label_id.cpu().numpy())

        pre.append(predictions)
    # final_pre =  pre[0]+pre[1]+pre[2]+pre[3]+pre[4]+pre[5]+pre[6]+pre[7]
    # five_pre = np.argmax(final_pre,axis=1)
    one = np.argmax(pre[0],axis=1)
    two = np.argmax(pre[1],axis=1)
    three = np.argmax(pre[2],axis=1)
    four = np.argmax(pre[3],axis=1)
    five = np.argmax(pre[4],axis=1)
    a = np.argmax(pre[5],axis=1)
    b = np.argmax(pre[6],axis=1)
    c = np.argmax(pre[7],axis=1)
    d = np.argmax(pre[8],axis=1)
    e = np.argmax(pre[9],axis=1)
    f = np.argmax(pre[10],axis=1)
    five_pre = []
    for i in range(len(pre[0])):
        tmp = [one[i],two[i],three[i],four[i],five[i],a[i],b[i],c[i],d[i],e[i],f[i]]
        count = dict(Counter(tmp))
        v = sorted(count.items(),key=lambda x:x[1],reverse=True)[0][0]
        five_pre.append(v)

    # 4. dump results
    with open(args.test_output_csv, 'w') as f:
        for pred_label_id, ann in zip(five_pre, dataset.anns):
            video_id = ann['id']
            category_id = lv2id_to_category_id(pred_label_id)
            f.write(f'{video_id},{category_id}\n')


if __name__ == '__main__':
    inference()
