import logging
import os
import time
import torch

from config36 import parse_args
from data_helper36 import create_dataloaders
from model36 import MultiModal
from util import setup_device, setup_seed, setup_logging, build_optimizer, evaluate



class FGM():
    def __init__(self, model):
        self.model = model
        self.backup = {}

    def attack(self, epsilon=1., emb_name='word_embeddings.weight'):
        # emb_name这个参数要换成你模型中embedding的参数名
        for name, param in self.model.named_parameters():
            if param.requires_grad and emb_name in name and 'video_bert' not in name:
                self.backup[name] = param.data.clone()
                norm = torch.norm(param.grad)
                if norm != 0:
                    r_at = epsilon * param.grad / norm
                    param.data.add_(r_at)

    def restore(self,  emb_name='word_embeddings.weight'):
        # emb_name这个参数要换成你模型中embedding的参数名
        for name, param in self.model.named_parameters():
            if param.requires_grad and emb_name in name and 'video_bert' not in name:
                assert name in self.backup
                param.data = self.backup[name]
        self.backup = {}



class EMA():
    def __init__(self, model, decay):
        self.model = model
        self.decay = decay
        self.shadow = {}
        self.backup = {}

    def register(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone()

    def update(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                new_average = (1.0 - self.decay) * param.data + self.decay * self.shadow[name]
                self.shadow[name] = new_average.clone()

    def apply_shadow(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.shadow
                self.backup[name] = param.data
                param.data = self.shadow[name]

    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                assert name in self.backup
                param.data = self.backup[name]
        self.backup = {}
        
        
def validate(model, val_dataloader):
    model.eval()
    predictions = []
    labels = []
    losses = []
    with torch.no_grad():
        for batch in val_dataloader:
            loss, _, pred_label_id, label = model(batch)
            loss = loss.mean()
            predictions.extend(pred_label_id.cpu().numpy())
            labels.extend(label.cpu().numpy())
            losses.append(loss.cpu().numpy())
    loss = sum(losses) / len(losses)
    results = evaluate(predictions, labels)

    model.train()
    return loss, results


def train_and_validate(args,se):
    # 1. load data
    train_dataloader, val_dataloader = create_dataloaders(args)


    # 2. build model and optimizers
    model = MultiModal(args)
    # model.load_state_dict(weight)
    optimizer, scheduler = build_optimizer(args, model)
    if args.device == 'cuda':
        model = torch.nn.parallel.DataParallel(model.to(args.device))
    for name, param in model.named_parameters():
        print(name)
    ema = EMA(model, 0.999)
    ema.register()
     # 初始化
    fgm = FGM(model)
    #     初始化
    # pgd = PGD(model,'word_embeddings.weight')
    # K = 3
  
    # 3. training
    step = 0
    best_score = args.best_score
    start_time = time.time()
    num_total_steps = len(train_dataloader) * args.max_epochs

    for epoch in range(args.max_epochs):
        if epoch >= 3:
            break
        for batch in train_dataloader:
            model.train()
            loss, accuracy, _, _ = model(batch)
            loss = loss.mean()
            accuracy = accuracy.mean()
            loss.backward()

            # 对抗训练
            fgm.attack()  # 在embedding上添加对抗扰动
            loss_adv, accuracy_adv, _, _ = model(batch)
            loss_adv = loss_adv.mean()
            loss_adv.backward()  # 反向传播，并在正常的grad基础上，累加对抗训练的梯度
            fgm.restore()  # 恢复embedding参数
            optimizer.step()
            ema.update()
            optimizer.zero_grad()
            scheduler.step()
            step += 1
            if step % args.print_steps == 0:
                time_per_step = (time.time() - start_time) / max(1, step)
                remaining_time = time_per_step * (num_total_steps - step)
                remaining_time = time.strftime('%H:%M:%S', time.gmtime(remaining_time))
                logging.info(f"Epoch {epoch} step {step} eta {remaining_time}: loss {loss:.3f}, accuracy {accuracy:.3f}")

        # 4. validation
        ema.apply_shadow()   

        state_dict = model.module.state_dict() if args.device == 'cuda' else model.state_dict()
        torch.save({'epoch': epoch, 'model_state_dict': state_dict},
                       f'{args.savedmodel_path}/model_epoch_{epoch}_{se}.bin')
        ema.restore()  # 下一次训练之前，恢复模型参数
        # ema.apply_shadow()   
        # loss, results = validate(model, val_dataloader)
        # results = {k: round(v, 4) for k, v in results.items()}
        # logging.info(f"Epoch {epoch} step {step}: loss {loss:.3f}, {results}")
        # # ema.restore()  # 下一次训练之前，恢复模型参数
        # # 5. save checkpoint
        # mean_f1 = results['mean_f1']
        # if mean_f1 > best_score:
        #     # ema.apply_shadow()
        #     best_score = mean_f1 
        #     state_dict = model.module.state_dict() if args.device == 'cuda' else model.state_dict()
        #     torch.save({'epoch': epoch, 'model_state_dict': state_dict, 'mean_f1': mean_f1},
        #                f'{args.savedmodel_path}/model_epoch_{epoch}_mean_f1_{mean_f1}_{se}.bin')  ## 这里修改se
        # ema.restore()  # 下一次训练之前，恢复模型参数


def main():
    args = parse_args()
    setup_logging()
    setup_device(args)
    for se in [42,200,1027,1995,2000,2004,2005,2008,2016,2021,2022]:
        setup_seed(se)

        os.makedirs(args.savedmodel_path, exist_ok=True)
        logging.info("Training/evaluation parameters: %s", args)

        train_and_validate(args,se)


if __name__ == '__main__':
    main()
