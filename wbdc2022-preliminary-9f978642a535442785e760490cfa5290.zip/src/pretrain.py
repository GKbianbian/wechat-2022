import logging
import os
import time
import torch

from config36 import parse_args
from data_helper36 import pretrain_dataloaders
from model36 import MultiModal
from util import setup_device, setup_seed, setup_logging, build_optimizer, evaluate



def train_and_validate(args):
    # 1. load data
    train_dataloader, val_dataloader = pretrain_dataloaders(args)

    # 2. build model and optimizers
    model = MultiModal(args)
    optimizer, scheduler = build_optimizer(args, model)
    if args.device == 'cuda':
        model = torch.nn.parallel.DataParallel(model.to(args.device))
    # for name, param in model.named_parameters():
    #     print(name)

    # 3. training
    step = 0
    best_score = 0
    start_time = time.time()
    num_total_steps = len(train_dataloader) * args.max_epochs

    for epoch in range(args.max_epochs):
        for batch in train_dataloader:
            model.train()
            loss = model(batch)
            loss[0].backward()
            # print(loss)
            logging.info("Loss:{} mlm:{} mfm:{}".format(loss[0], loss[1], loss[2]))
            # logging.INFO("Loss:{} mlm:{} mfm:{}".format(loss[0],loss[1],loss[2]))
            optimizer.step()
            optimizer.zero_grad()
            scheduler.step()
            step += 1
            #logging.info(f"Epoch {epoch} step {step}: loss {loss:.3f}")

        torch.save(model.state_dict(),{'epoch'+str(epoch)+'pretrain.bin'})



def main():
    args = parse_args()

    args.do_pretrain = 1
    args.max_epochs = 10
    args.batch_size = 16

    setup_logging()
    setup_device(args)
    setup_seed(args)

    os.makedirs(args.savedmodel_path, exist_ok=True)
    logging.info("Training/evaluation parameters: %s", args)
    # print(os.path.exists('input/pretrain-model/roberta-wwm'))
    train_and_validate(args)


if __name__ == '__main__':
    main()
