cd src/

python inference.py
