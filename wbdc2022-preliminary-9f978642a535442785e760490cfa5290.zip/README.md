## 代码说明

### 环境配置

Python 版本：3.7
PyTorch 版本：1.1.0
CUDA 版本：10.0

所需环境在 `requirements.txt` 中定义。

### 数据

* 仅使用大赛提供的有标注数据（10万）。
* 未使用任何额外数据。

### 预训练模型

* 使用了 huggingface 上提供的 `hfl/roberta-wwm`` 模型

### 算法描述

* 对于文本特征，文本有 title、asr、ocr 三种，通过将三种文本拼接在一起，如 [CLS] + title + [SEP] + asr + [SEP] + ocr + [SEP] 这种形式。
* 对于视觉特征，首先经过一层线性层进行 dense （ shape 为 [bs, frame size, hidden_size]），然后再经过一个激活函数（这里可以理解为 video 的特征是通过 swin transformer 进行提取的，特征的分布和 bert 的极为不一致的，通过线性层的映射，可以稍微的缓解异质空间的不一致问题），再将通过线性层映射之后的 video 特征再经过与文本特征经过的同一个的 bert embedding 层（ shape 为 [bs, frame size, hidden_size]），使得 video embedding 经过 bert 的 embedding 层进行映射，让 video embedding 可以或者 和 text embedding一样的特征分布。
* 视觉和文本特征直接连接起来，通过将两个 embedding 进行拼接（ shape 为 [bs, seq_length + frame size, hidden_size]），然后再将两个 embedding 对应的 mask 也进行拼接。最后，将拼接的 embedding 与 mask 送入到 bert 的 encoder 中去编码，得到最后一层的隐层状态 last hidden states（ shape 为 [bs, seq_length + frame size, hidden_size]），然后通过 mean pooling 操作，得到最后的特征表示，最后经过线性层进行 200 分类。
*  Trick 方面。这里会简单阐述一些NLP竞赛中常见的 trick。第一：使用EMA。第二：使用对抗训练，FGM通过对 bert 的word embeddings 层进行微小的扰动来提升模型的泛化能力。第三：模型权重分层，将bert权重与分类层分开。第四：模型调参。
* 利用11个不同的种子进行全量学习，再通过投票进行了融合。



### 性能

离线测试性能：全量训练，按照经验，第三轮效果最佳
B榜测试性能：0.68552


### 训练流程

* 无预训练，直接在有标注数据上训练。

### 测试流程

* 全量学习。
